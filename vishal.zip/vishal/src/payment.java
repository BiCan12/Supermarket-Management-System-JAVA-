
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class payment implements ActionListener
{
     JLabel lb,lb1;
     JPanel jp;
     JFrame f;
     JButton jb,jb1,jb2,jb3;
    public payment()
    {
        f=new JFrame();
         f = new JFrame();
        f.setSize(852, 480);
        f.setVisible(true);
        f.setLocation(250, 150);
        f.setResizable(false);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ImageIcon ii = new ImageIcon("img/5.jpg");
        lb = new JLabel(ii);
        f.add(lb);
        JPanel jp= new JPanel();
        jp.setLayout(null);
        
        jp.setOpaque(false);
        jp.setBounds(0, 0, 852, 480);
        lb.add(jp);
       JLabel lb1=new JLabel("PAYMENT OPTIONS");
       lb1.setBounds(250, 50, 350, 100);
       lb1.setForeground(Color.white);
       lb1.setFont(new Font("times new roman", Font.BOLD|Font.ITALIC, 30));
       jp.add(lb1);
       jb=new JButton("NET BANKING");
       jb.setBounds(200, 175, 150, 30);
       jb.setFont(new Font("arial", Font.BOLD, 14));
        Cursor cur=new Cursor(Cursor.HAND_CURSOR);
       jb.setCursor(cur);
       jb.addActionListener(this);
       jp.add(jb);
       jb1=new JButton("CREDIT CARD");
       jb1.setBounds(450, 175, 150, 30);
       jb1.setFont(new Font("arial", Font.BOLD, 14));
       jb1.setCursor(cur);
       jp.add(jb1);
       jb2=new JButton("DEBIT CARD");
       jb2.setBounds(200, 275, 150, 30);
       jb2.setCursor(cur);
       jb2.setFont(new Font("arial", Font.BOLD, 14));
       jp.add(jb2);
       jb3=new JButton("COD");
       jb3.setBounds(450, 275, 150, 30);
       jb3.setCursor(cur);
       jb3.setFont(new Font("arial", Font.BOLD, 14));
       jp.add(jb3);
      
    }
    
    @Override
    public void actionPerformed(ActionEvent e)
    {
        Object obj=e.getSource();
        if(obj==jb)
        {
            new banking();
        }
    }
     
}
