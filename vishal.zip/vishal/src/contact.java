
import java.awt.Choice;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class contact implements ActionListener,ItemListener{

    JFrame f;
    JPanel jp;
    JLabel lb, lb1, lb2, lb3, lb4, lb5;
    JTextField tf, tf1, tf2, tf3;
    JTextArea ta;
    JButton jb, jb1;
    Cursor c;
    Choice c1,c2;
    int id = 0;

    public contact(int id) {
        this.id = id;
        f = new JFrame();
        f.setVisible(true);
        f.setSize(1160, 772);
        f.setLocation(100, 0);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(false);
        ImageIcon ii = new ImageIcon("img/vegetable-set-3.jpg");
//        ii = new ImageIcon(getClass().getResource("\\img\\5.jpg"));
        lb = new JLabel(ii);
        f.add(lb);
        jp = new JPanel();
        jp.setBounds(0, 0, 1160, 772);
        jp.setOpaque(false);
        jp.setLayout(null);
        lb.add(jp);
        lb1 = new JLabel("MOBILE NO.:");
        lb1.setForeground(Color.WHITE);
        lb1.setFont(new Font("comic sans ms", Font.BOLD, 26));
        lb1.setBounds(250, 150, 200, 60);
        jp.add(lb1);
        lb2 = new JLabel("E-MAIL ID:");
        lb2.setForeground(Color.WHITE);
        lb2.setFont(new Font("comic sans ms", Font.BOLD, 26));
        lb2.setBounds(250, 220, 200, 60);
        jp.add(lb2);
        lb3 = new JLabel("STATE:");
        lb3.setBounds(250, 290, 200, 60);
        lb3.setForeground(Color.WHITE);
        lb3.setFont(new Font("comic sans ms", Font.BOLD, 26));
        jp.add(lb3);
        c1=new Choice();
        c1.setBounds(500, 315, 150, 30);
        c1.add("STATE");
        c1.add("RAJASTHAN");
        c1.add("UTTAR PRADESH");
        c1.add("GUJRAT");
        c1.add("PUNJAB");
        c1.add("HARYANA");
        c1.add("KERELA");
        c1.add("TAMIL NADU");
        c1.add("MAHARASHTRA");
        c1.add("ANDHRA PRADESH");
        c1.add("WEST BENGAL");
        c1.addItemListener(this);
        jp.add(c1);
        tf = new JTextField();
        tf.setBounds(500, 160, 300, 40);
        jp.add(tf);
        tf1 = new JTextField();
        tf1.setBounds(500, 230, 300, 40);
        jp.add(tf1);
        ta = new JTextArea();
        ta.setBounds(500, 460, 300, 50);
        jp.add(ta);
        lb4 = new JLabel("CITY:");
        lb4.setForeground(Color.WHITE);
        lb4.setFont(new Font("comic sans ms", Font.BOLD, 26));
        lb4.setBounds(250, 375, 100, 40);
        jp.add(lb4);
        c2=new Choice();
        c2.setBounds(500, 390, 150, 30);
        jp.add(c2);
        c2.add("CITY");
        lb5 = new JLabel("ADDRESS:");
        lb5.setForeground(Color.WHITE);
        lb5.setFont(new Font("comic sans ms", Font.BOLD, 26));
        lb5.setBounds(250, 460, 200, 40);
        jp.add(lb5);
//        tf2 = new JTextField();
//        tf2.setBounds(500, 390, 300, 40);
//        jp.add(tf2);
//        tf3 = new JTextField();
//        tf3.setBounds(500, 460, 300, 40);
//        jp.add(tf3);
        jb = new JButton("NEXT");
        jb.setBounds(950, 300, 100, 40);
        jb.setFont(new Font("arial", Font.BOLD, 14));
        jp.add(jb);
        jb.addActionListener(this);
        c = new Cursor(Cursor.HAND_CURSOR);
        jb.setCursor(c);
        jb1 = new JButton("BACK");
        jb1.setBounds(50, 300, 100, 40);
        jb1.setFont(new Font("arial", Font.BOLD, 14));
        jb1.setCursor(c);
        jp.add(jb1);
        jb1.addActionListener(this);
    }
   

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if (obj == jb1) {
            new register();
        } else if (obj == jb) {
            boolean t=true;
            String s = tf.getText();
            String s1 = tf1.getText();
            String s2 = ta.getText();
            String s3 = c2.getSelectedItem();
            String s4 = c1.getSelectedItem();
                if (s.isEmpty() || s1.isEmpty() || s2.isEmpty() || s3.isEmpty() || s4.isEmpty())
            {
                JOptionPane.showMessageDialog(f, "Please fill all the details");
            }
            else if(s3=="CITY" || s4=="STATE")
            {
                JOptionPane.showMessageDialog(f, "PLEASE CHOOSE VALID OPTION");
            }
            else if(s.length()<10 || s.length()>10)
            {
                JOptionPane.showMessageDialog(f, "PLEASE ENTER VALID MOBLIE NUMBER");
            }
            else if(s.startsWith("1")||s.startsWith("2")||s.startsWith("3")||s.startsWith("4")||s.startsWith("5")||s.startsWith("6")||s.startsWith("0"))
                    {
                        JOptionPane.showMessageDialog(f, "PLEASE ENTER VALID MOBILE NO.");
                    }
//            else if(t!=s1.endsWith("@gmail.com"))
//            {
//                JOptionPane.showMessageDialog(f, "PLEASE ENTER VALID E-MAIL ID");
//            }
//            
            else
            {
                Connection conn = dbconnection.getConnect();
                try {
                    PreparedStatement pst = conn.prepareStatement("UPDATE `grofers` SET `mobileno`=?,`email`=?,`address`=?,`city`=?,`state`=? WHERE `id`=?");
                    pst.setString(1, s);
                    pst.setString(2, s1);
                    pst.setString(3, s2);
                    pst.setString(4, s3);
                    pst.setString(5, s4);
                    String a = Integer.toString(id);
                    pst.setString(6, a);
                    int check = pst.executeUpdate();
                    System.out.println("second insert query.................." + pst);
                    if (check == 1) {
//                        System.out.println("1");
                        f.setVisible(false);
                        f.dispose();
                        new password(id);
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(contact.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e)
    {
        Object obj=e.getSource();
        if(obj==c1)
        {
           String s=c1.getSelectedItem();
           if(s=="RAJASTHAN")
           {
               c2.add("JAIPUR");
               c2.add("AJMER");
               c2.add("BIKANER");
               c2.add("SIKAR");
               c2.add("ALWAR");
               c2.add("BADMER");
               c2.add("UDAIPUR");
               c2.add("KOTA");
               c2.add("BEAWAR");
               c2.add("JAISALMER");
           }
           if(s=="UTTAR PRADESH")
           {
               c2.add("MEERUT");
               c2.add("LUCKNOW");
               c2.add("AGRA");
               c2.add("KANPUR");
               c2.add("VARANASI");
               c2.add("ALLAHBAD");
               c2.add("MATHURA");
               c2.add("JHANSI");
               c2.add("ALIGARH");
               c2.add("GONDA");
           }
           if(s=="GUJRAT")
           {
               c2.add("SURAT");
               c2.add("AHEMDABAD");
               c2.add("GANDHINAGAR");
               c2.add("BHUJ");
               c2.add("VERAWAL");
               c2.add("DWARKA");
               c2.add("GONDAL");
               c2.add("ANKALESHWAR");
               c2.add("BHAVNAGAR");
               c2.add("JAMNAGAR");
           }
           if(s=="PUNJAB")
           {
               c2.add("LUDHIANA");
               c2.add("AMRITSAR");
               c2.add("PATIALA");
               c2.add("MOHALI");
               c2.add("CHANDIGARH");
               c2.add("JALANDHAR");
               c2.add("PATHANKOT");
               c2.add("FIROZPUR");
               c2.add("ANANDPUR");
               c2.add("NANGAL");
           }
           if(s=="HARYANA")
           {
               c2.add("FARIDABAD");
               c2.add("ROHTAK");
               c2.add("KARNAL");
               c2.add("HISAR");
               c2.add("BAHADURGARH");
               c2.add("GURGAON");
               c2.add("YAMUNANAGAR");
               c2.add("NEW DELHI");
               c2.add("PANIPAT");
               c2.add("HANSI");
           }
           if(s=="KERELA")
           {
               c2.add("KOCCHI");
               c2.add("THIRUVANANTHAPURAM");
               c2.add("THRISSUR");
               c2.add("KANNUR");
               c2.add("ALAPPUZHA");
               c2.add("KOLLAM");
               c2.add("MUNNAR");
               c2.add("BEKAL");
               c2.add("TIRUR");
           }
           if(s=="TAMIL NADU")
           {
               c2.add("CHENNAI");
               c2.add("SALEM");
               c2.add("VELLORE");
               c2.add("OOTY");
               c2.add("KANNYAKUMARI");
               c2.add("TIRUCHIRRAPALI");
               c2.add("KANCHIPURAM");
               c2.add("HOSUR");
               c2.add("RAMESHWARAM");
               c2.add("TIRUPPUR");
           }
           if(s=="MAHARASHTRA")
           {
               c2.add("PUNE");
               c2.add("MUMBAI");
               c2.add("THANE");
               c2.add("NAGPUR");
               c2.add("AURANGABAD");
               c2.add("AMRAVATI");
               c2.add("KOLAHPUR");
               c2.add("MAHABALESHWAR");
               c2.add("LONAVNA");
               c2.add("MATHERAN");
           }
           if(s=="WEST BENGAL")
           {
               c2.add("KOLKATA");
               c2.add("KHARAGPUR");
               c2.add("DURGAPUR");
               c2.add("HOWRAH");
               c2.add("MIDNAPORE");
               c2.add("BAHARAMUR");
               c2.add("SHANTIPUR");
               c2.add("DARJEELING");
               c2.add("SILLIGURI");
               c2.add("DHULIAN");
           }
           if(s=="ANDHRA PRADESH")
           {
               c2.add("VIJAYAWADA");
               c2.add("TIRUPATI");
               c2.add("VISHAKHAPATNAM");
               c2.add("GUNTUR");
               c2.add("KURNOOL");
               c2.add("NELLORE");
               c2.add("ONGOLE");
               c2.add("NANDYAL");
               c2.add("TENALI");
           }
        }
    }
}
