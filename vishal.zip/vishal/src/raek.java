
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class raek implements ActionListener {

    JFrame f;
    JPanel jp, jp1, jp2;
    JLabel lb, lb1, lb2, lb3, lb4, lb5, lb6, lb7, lb8, lb9, lb10;
    ImageIcon ii;
    JButton jb, jb1;
    Color c = new Color(248, 75, 8);
    Cursor cur = new Cursor(Cursor.HAND_CURSOR);

    public raek() {
        createframe();
        createpanel();
        createlabel();
        createsecondpanel();
    }

    void createframe() {
        f = new JFrame("WELCOME TO GROFERS!!");
        f.setVisible(true);
        f.setSize(1366, 768);
         f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(false);

    }

    void createpanel() {
        jp = new JPanel();
        jp.setBounds(0, 0, 1366, 768);

        jp.setLayout(null);
        jp.setOpaque(false);
        f.add(jp);

    }

    void createlabel() {

        jp1 = new JPanel();
        jp1.setBackground(Color.WHITE);
        jp1.setBounds(0, 0, 1366, 200);
        jp1.setLayout(null);
        ImageIcon img = new ImageIcon("img/unnamed.png");
        lb = new JLabel();
        lb.setIcon(img);
        lb.setBounds(5, 15, 150, 170);
        lb1 = new JLabel("GROFERS!!!");
        lb1.setBounds(550, 50, 500, 80);

        lb1.setFont(new Font("elephanta", Font.BOLD | Font.ITALIC, 55));
        lb1.setForeground(c);
        lb9 = new JLabel("<html><marquee>BUY ONLINE VEGETABLES AND FRUITS</marquee></html>");
        lb9.setFont(new Font("comic sans ms", Font.ITALIC | Font.BOLD, 14));
        lb9.setForeground(c);
        lb9.setBounds(880, 110, 300, 30);
        jb = new JButton("LOG IN");
        jb.addActionListener(this);
        jb.setBounds(1050, 20, 100, 20);
        jb.setBackground(c);
        jb.setForeground(Color.WHITE);
        jb.setCursor(cur);
        jb.setFont(new Font("arial", Font.BOLD, 14));
        jb1 = new JButton("SIGN UP");
        jb1.setBounds(1200, 20, 100, 20);
        jb1.setBackground(c);
        jb1.addActionListener(this);
        jb1.setForeground(Color.WHITE);
        jb1.setFont(new Font("arial", Font.BOLD, 14));
        jb1.setCursor(cur);
        jp.add(jp1);
        jp1.add(lb);
        jp1.add(lb1);
        jp1.add(jb);
        jp1.add(jb1);
        jp1.add(lb9);
    }

    void createsecondpanel() {
        jp2 = new JPanel();
        jp2.setLayout(null);
        jp2.setBounds(0, 150, 1366, 600);
        Color c = new Color(248, 75, 8);
        jp2.setBackground(c);
        ImageIcon i1 = new ImageIcon("img/1-640x452-150x150.jpg");
        lb2 = new JLabel();
        lb2.setIcon(i1);
        lb2.setBounds(1180, 70, 150, 150);
        jp.add(jp2);
        jp2.add(lb2);
        lb3 = new JLabel("<html>I am trying to build a place <br>where women don't find it<br> difficult to buy vegetables <br>and fruits.Grofers is "
                + "basically a platform that modernizez<br> india and indian women<br>.Our fruits and vegetables<br>are of supereme quality and<br>"
                + "we make sure that our customers are satisfied <br> with our service.Grofers would<br>help to improve the indian<br>economy and "
                + "also provide employment opportunities.<br>We ensure the top quality<br>of our products and also the best service of our<br>"
                + "valuable employees.</html>");
        lb3.setBounds(1180, 85, 186, 600);
        lb4 = new JLabel();
        ImageIcon i2 = new ImageIcon("img/d1be583d8873749d17628163db2f5f5f530eedba.jpg");
        lb4.setIcon(i2);
        lb4.setBounds(10, 70, 366, 273);
        lb5 = new JLabel("-ALBINDER DHINDSA(CEO)");
        lb5.setFont(new Font("arial", Font.BOLD | Font.ITALIC, 12));
        lb5.setBounds(1200, 500, 186, 100);
        lb6 = new JLabel();
        ImageIcon i3 = new ImageIcon("img/501172-grofers.jpg");
        lb6.setIcon(i3);
        lb6.setBounds(580, 70, 300, 300);
        ImageIcon i4 = new ImageIcon("img/Easy-App-Release-on-Google-Play-Store-and-iTunes-Store.png");
        lb7 = new JLabel();
        lb7.setBounds(600, 400, 254, 80);
        lb7.setIcon(i4);
        ImageIcon i5 = new ImageIcon("img/Easy-App-Release-on-Google-Play-Store-and-iTunes-Store (1).png");
        lb8 = new JLabel();
        lb8.setIcon(i5);
        lb8.setBounds(600, 500, 248, 80);
        lb10 = new JLabel("<html>We are a proud family of more than 10,000 people <br>We have only one aim to make our customers<br> happy by providing them"
                + "beest service and products<br> of supreme quality.We want to be number one in the <br>world.This is possible only with support of our<br>"
                + "customers.We will try our best to keep our<br> customers happy and not give them any chance for<br> bieng angry at us.");
        lb10.setBounds(10, 220, 366, 400);
        jp2.add(lb3);
        jp2.add(lb4);
        jp2.add(lb5);
        jp2.add(lb6);
        jp2.add(lb7);
        jp2.add(lb8);
        jp2.add(lb10);
    }

    public static void main(String args[]) {
        new raek();

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if (obj == jb) {
            f.setVisible(false);
            f.dispose();
            new login();
        }
        if (obj == jb1) {
            f.setVisible(false);
            f.dispose();
            new register();
        }
    }
}
