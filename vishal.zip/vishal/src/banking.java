import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class banking  implements ActionListener
{
    JFrame f;
    JLabel lb,lb1,lb2,lb3;
    Choice c;
    JTextField tf;
    JPasswordField pf;
    JButton jb;
    banking()
    {
        f=new JFrame();
        f.setSize(852, 480);
        
        f.setLocation(250, 150);
        f.setResizable(false);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ImageIcon ii = new ImageIcon("img/5.jpg");
        lb = new JLabel(ii);
        f.add(lb);
        JPanel jp= new JPanel();
        jp.setLayout(null);
       jp.setOpaque(false);
       jp.setBounds(0, 0, 852, 480);
       lb.add(jp);
       c=new Choice();
       c.setBounds(450, 100, 200, 100);
       c.add("STATE BANK OF INDIA");
       c.add("AXIS BANK");
       c.add("HDFC BANK");
       c.add("VIJAYA BANK");
       c.add("ICICI BANK");
       c.add("BANK OF BARODA");
       c.add("BANK OF INDIA");
       c.add("CANARA BANK");
       c.add("BANK OF ALLAHABAD");
       c.add("KOTAK MAHINDRA");
       c.add("STATE BANK OF BIKANER AND JAIPUR");
       c.add("STATE BANK OF HYDERABAD");
       c.add("STATE BANK OF TRAVANCORE");
       jp.add(c);
       lb1=new JLabel("CHOOSE YOUR BANK");
       lb1.setBounds(200, 60, 200, 100);
       lb1.setForeground(Color.WHITE);
       lb1.setFont(new Font("arial", Font.BOLD, 16));
       jp.add(lb1);
        lb2=new JLabel("USERNAME:");
       lb2.setBounds(200, 150, 200, 100);
       lb2.setForeground(Color.WHITE);
       lb2.setFont(new Font("arial", Font.BOLD, 16));
       jp.add(lb2);
       lb3=new JLabel("PASSWORD:");
       lb3.setBounds(200, 190, 200, 100);
       lb3.setForeground(Color.WHITE);
       lb3.setFont(new Font("arial", Font.BOLD, 16));
       jp.add(lb3);
       tf=new JTextField();
       tf.setBounds(450, 190,200, 20);
       jp.add(tf);
       pf=new JPasswordField();
       pf.setBounds(450, 230, 200, 20);
       jp.add(pf);
       jb=new JButton("SUBMIT");
       jb.setBounds(350, 300, 150, 25);
       Cursor cur=new Cursor(Cursor.HAND_CURSOR);
       jb.setCursor(cur);
       jb.addActionListener(this);
       jp.add(jb);
       f.setVisible(true);
    }
    public static void main(String args[])

    {
        new banking();
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        Object obj=e.getSource();
        if(obj==jb)
        {
            String s=tf.getText();
            String s1=pf.getText();
            if(s.isEmpty())
            {
                JOptionPane.showMessageDialog(f, "username is empty!!");
            }
            else if(s1.isEmpty())
            {
                JOptionPane.showMessageDialog(f, "password is empty");
            }
            else if(s.isEmpty() && s1.isEmpty())
            {
                JOptionPane.showMessageDialog(f, "above fields are empty");
            }
            else
            {
             JOptionPane.showMessageDialog(f, "required amount has been deducted from your account,wait you are being taken to home page");
             new raek();
        }
                
    }
    }
}
