import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
public class rules implements ActionListener
{
    JFrame f;
    JLabel lb,lb1,lb2;
    JPanel jp;
    JButton jb,jb1;
    Cursor s;

  public rules()
  {
      f=new JFrame();
      f.setVisible(true);
      f.setSize(852, 480);
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      f.setLocation(250, 150);
      ImageIcon ii=new ImageIcon("img/5.jpg");
      lb=new JLabel(ii);
      f.add(lb);
      jp=new JPanel();
      jp.setLayout(null);
      jp.setBounds(0, 0, 852, 480);
      jp.setOpaque(false);
      lb.add(jp);
//      lb1=new JLabel("<html><h1>GUIDELINES</html></h1>");
//      lb1.setForeground(Color.WHITE);
//      lb1.setBounds(350, 60, 200, 80);
//      lb1.setFont(new Font("elephanta", Font.BOLD | Font.ITALIC, 55));
//      jp.add(lb1);
      lb2=new JLabel("<html><ul><li>THERE ARE MAXIMUM 10 SLOTS AVAILABLE</li><br><li>IF THE SLOTS ARE COMPLETED YOU CAN PLACE THE ORDER AND<br> CONTINUE SHOPPING "
              + "FOR THE NEXT TIME</li><br><li>DIFFERENT PROMO CODES ARE AVAILABLE TO GIVE YOU<br> VALUABLE DISCOUNT AT TIME OF PAYMENT</ul></html>");
      lb2.setBounds(120, -10, 852, 400);
      lb2.setFont(new Font("comic sans ms", Font.BOLD|Font.ITALIC, 16));
      lb2.setForeground(Color.WHITE);
      jp.add(lb2);
      jb=new JButton("LOGOUT");
       f.setResizable(false);
      s=new Cursor(Cursor.HAND_CURSOR);
      jb.setCursor(s);
      jb.setBounds(250, 300, 120, 30);     
       jb.setFont(new Font("arial", Font.BOLD, 14));
     jb.addActionListener(this);
      jp.add(jb);
      jb1=new JButton("BUY NOW");
      jb1.addActionListener(this);
      jb1.setBounds(420, 300, 120, 30);     
       jb1.setFont(new Font("arial", Font.BOLD, 14));
       jb1.setCursor(s);
      jp.add(jb1);
  }
    public static void main(String[] args)
    {
        new rules();
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        Object obj=e.getSource();
        if(obj==jb)
        {
           new raek(); 
           f.setVisible(false);
           f.dispose();
        }
        if(obj==jb1)
        {
            new buyveggies();
            f.setVisible(false);
            f.dispose();
        }
    }
}
