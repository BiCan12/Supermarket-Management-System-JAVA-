
public class NewClass
{
    public static void main(String args[])
    {
       
        String s="hello";
        String s1="world";
        int l=s.length();
        System.out.println(l);
        char a=s.charAt(4);
        System.out.println(a);
        String s2=s.concat(s1);
        System.out.println(s2);
        String s3=s2.substring(0, s2.length()-3);
        System.out.println(s3);
        int t=s3.compareTo(s2);
        System.out.println(t);
        boolean t1=s3.equalsIgnoreCase(s1);
        System.out.println(t1);
        boolean t2=s2.equals(s1);
        System.out.println(t2);
        String s4=s.replace("l", "d");
        System.out.println(s4);
        int b=s.lastIndexOf(s4);
        System.out.println(b);
       boolean t3= s.isEmpty();
       System.out.println(t3);
       String s5="     rafa nadal    ";
       String s6=s5.trim();
        System.out.println(s6);
       String s7=s1.toUpperCase();
                System.out.println(s7);      
       String s8=s7.toLowerCase();
           System.out.println(s8); 
          boolean t4=s6.endsWith("dal");
          System.out.println(t4);
          boolean t5=s6.startsWith("na");
          System.out.println(t5);
          String st="tommorrowland";
          char[] arr;
        arr = new char[40];
         arr=st.toCharArray();
 System.out.println(arr);
      String arr1="howdy!!!";
      byte[] by=new byte[10];
     by= arr1.getBytes();
     System.out.println(by);
     String st1="welcome to chennai!!!";
     String st2=st1.substring(4, 10);
     System.out.println(st2);
     String a1="233435345";
     String st3=a1.toString();
     System.out.println(st3);
     String st4="my name is vishal";
     int n=st4.hashCode();
     System.out.println(n);

        System.out.println("these are string buffer functions!!");
     StringBuffer bf=new StringBuffer("WELCOME");
     int c=bf.capacity();
     System.out.println(c);
     StringBuffer bf1=new StringBuffer("hello!");
     StringBuffer bf2=new StringBuffer(bf1.reverse());
     System.out.println(bf2);
     StringBuffer bf3=new StringBuffer("wassup!!");
     StringBuffer bf4=new StringBuffer(bf3.delete(2, 4));
     System.out.println(bf4);
     StringBuffer bf5=new StringBuffer("welcome");
        StringBuffer bf6=new StringBuffer(bf5.deleteCharAt(4));
        System.out.println(bf6);
         StringBuffer bf7=new StringBuffer("welcome");
        StringBuffer bf8=new StringBuffer(bf7.reverse());
        System.out.println(bf8);    
         StringBuffer bf9=new StringBuffer("insomniac");
         String str="ssup!";
         StringBuffer bf10=new StringBuffer(bf9.replace(2, 6, str));
         System.out.println(bf10);
         StringBuffer bf11=new StringBuffer("hola!!");
        int n1=bf11.hashCode();
        System.out.println(n1);
        StringBuffer bf12=new StringBuffer("welcome");
                 StringBuffer bf13=new StringBuffer("to goa");      
           StringBuffer bf14=new StringBuffer(bf12.toString());
           System.out.println(bf14);
                 StringBuffer bf15=new StringBuffer(bf12.append(bf13));  
                          System.out.println(bf15);  
                         char ch= bf12.charAt(6);
                            System.out.println(ch);
                  
                            StringBuffer bf16=new StringBuffer(  bf15.deleteCharAt(7));  
                            int l1=bf11.length();
                                     System.out.println(l1);
                
                    
                  
  }
}
    

