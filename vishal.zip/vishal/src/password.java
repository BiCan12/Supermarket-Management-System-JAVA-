
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class password implements ActionListener {

    JFrame f;
    JLabel lb, lb1, lb2;
    JPasswordField pf;
    JButton jb;
    Cursor c = new Cursor(Cursor.HAND_CURSOR);
    private int id;

    password(int id) {
        this.id = id;
        f = new JFrame();
        f.setSize(852, 480);
        f.setVisible(true);
        f.setLocation(250, 150);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ImageIcon ii = new ImageIcon("img/5.jpg");
        lb = new JLabel(ii);
        f.add(lb);
        JPanel j = new JPanel();
        j.setLayout(null);
        j.setOpaque(false);
        j.setBounds(0, 0, 852, 480);
        lb.add(j);
        lb1 = new JLabel("PASSWORD:");
        lb1.setForeground(Color.WHITE);
        lb1.setFont(new Font("comic sans ms", Font.BOLD, 26));
        lb1.setBounds(200, 150, 200, 60);
        j.add(lb1);
        pf = new JPasswordField();
        pf.setBounds(400, 155, 300, 40);
        j.add(pf);
        lb2 = new JLabel("Password must contain at least 6 characters");
        lb2.setForeground(Color.WHITE);
        lb2.setFont(new Font("arial", 0, 12));
        lb2.setBounds(400, 190, 300, 40);
        j.add(lb2);
        jb = new JButton("SUBMIT");
        jb.setBounds(375, 250, 100, 25);
        jb.setFont(new Font("arial", Font.BOLD, 14));
        j.add(jb);
        jb.setCursor(c);
        jb.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if (obj == jb) {
           String s=String.valueOf(pf.getPassword());
            
            if (s.isEmpty())
            {
                JOptionPane.showMessageDialog(f, "do not leave the above field empty");
            } 
            else if (s.length() < 6) 
            {
                JOptionPane.showMessageDialog(f, "password must contain at least 6 characters");
            } 
             else {
                Connection conn = dbconnection.getConnect();
                try {
                    PreparedStatement pst = conn.prepareStatement("UPDATE `grofers` SET `password` = ? WHERE `id`=?");
                    pst.setString(1, s);
                    pst.setInt(2, id);
                    int check = pst.executeUpdate();
                    if (check == 1) {
                        JOptionPane.showMessageDialog(f, "your account has been created successfully, please wait page redirected to home.");
                        f.setVisible(false);
                        f.dispose();
                        new raek();
                    } else {
                        System.out.println("password not inserted.....");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(password.class.getName()).log(Level.SEVERE, null, ex);
                }
//                JOptionPane.showMessageDialog(f, "you are bieng directed to home page");
//                f.setVisible(false);
//                String args[] = {};
//                raek.main(args);
//                f.dispose();
            }
        }
    }
}
