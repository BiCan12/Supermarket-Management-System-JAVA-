
import java.sql.Connection;
import java.sql.DriverManager;


public class dbconnection 
{
        public static Connection getConnect() {
        Connection conn = null;
        try {
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/grofers", "root", "root");
        } catch (Exception ex) {

            ex.printStackTrace();
        }
        return conn;
    }    
}
