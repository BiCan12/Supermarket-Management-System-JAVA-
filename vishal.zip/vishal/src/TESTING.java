
import java.awt.Choice;
import java.awt.Cursor;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class TESTING implements ItemListener
{
    Choice c1,c2;
    JFrame f;
    JPanel jp;
     TESTING()
    {
       f = new JFrame("WELCOME TO GROFERS!!");
        f.setVisible(true);
        f.setSize(300, 300);
         f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(false);
         jp=new JPanel();
        jp.setBounds(0, 0, 300, 300);
        jp.setOpaque(false);
        jp.setLayout(null);
        f.add(jp);
        c1=new Choice();
        c1.setBounds(50, 50, 100, 50);
        c1.add("-");
        c1.add("rajasthan");
        c1.add("uttar pradesh");
        c1.addItemListener(this);
        c2=new Choice();
        c2.setBounds(50, 150, 100, 50);
        jp.add(c1);
        jp.add(c2);
//        JButton btn=new JButton("press");
//        btn.setBounds(50, 50,100 , 40);
//        Cursor cur=new Cursor(Cursor.HAND_CURSOR);
//        btn.setCursor(cur);
//        jp.add(btn);
    
    }
public static void main(String args[])
{
  new TESTING();
}

    @Override
    public void itemStateChanged(ItemEvent e)
    {
        Object obj=e.getSource();
        if(obj==c1)
        {
            String s=c1.getSelectedItem();
            if(s=="rajasthan")
            {
                c2.add("jaipur");
                c2.add("ajmer");
            }
        }
    }
}