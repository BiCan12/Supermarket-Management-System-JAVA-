import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPasswordField;
public class login implements ActionListener
{
    JFrame jf;
    JLabel lb,lb1,lb2;
    JTextField tf;
    JPasswordField tf1;
    JPanel jp;
    JButton jb,jb1;
    Cursor cur=new Cursor(Cursor.HAND_CURSOR);
    login()
    {
        jf=new JFrame();
        jf.setVisible(true);
        jf.setSize(1160, 772); 
        jf.setLocation(100, 0);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setResizable(false);
        ImageIcon ii=new ImageIcon("img/vegetable-set-3.jpg");
        lb=new JLabel(ii);
        jf.add(lb);
        lb1=new JLabel("USERNAME:");
        lb1.setForeground(Color.WHITE);
        lb1.setFont(new Font("comic sans ms", Font.BOLD | Font.ITALIC, 26));
        lb1.setBounds(300, 150, 200, 60);
        jp=new JPanel();
        jp.setBounds(0, 0, 1160, 772);
        jp.setLayout(null);
        jp.setOpaque(false);
        lb.add(jp);
        jp.add(lb1);
        tf=new JTextField();
        tf.setBounds(500, 160, 300, 40);
        jp.add(tf);
        lb2=new JLabel("PASSWORD:");
         lb2.setForeground(Color.WHITE);
        lb2.setFont(new Font("comic sans ms", Font.BOLD | Font.ITALIC, 26));
        lb2.setBounds(300, 250, 200, 40);
        jp.add(lb2);
        tf1=new JPasswordField();
        tf1.setBounds(500, 255, 300, 40);
        jp.add(tf1);
        jb=new JButton("SUBMIT");
        jb.setBounds(450, 350, 100, 25);
        jb.setFont(new Font("arial", Font.BOLD, 14));
        jb.setCursor(cur);
        jb.addActionListener(this);
        jp.add(jb);
        jb1=new JButton("HOME");
        jb1.setBounds(600, 350, 100, 25);
        jb1.setFont(new Font("arial", Font.BOLD, 14));
        jp.add(jb1);
        jb1.setCursor(cur);
        jb1.addActionListener(this);
    }
          

    @Override
    public void actionPerformed(ActionEvent e)
    {
        Object obj=e.getSource();
        if(obj==jb)
        {
            String s=tf.getText();
            String s1=tf1.getText();
            if(s.isEmpty())
            {
                JOptionPane.showMessageDialog(jf, "USERNAME IS EMPTY!!!");
            }
            else if(s1.isEmpty())
            {
                JOptionPane.showMessageDialog(jf, "PASSWORD IS EMPTY!!!");
            }
            else
            {
                Connection conn=dbconnection.getConnect();
                try {
                    PreparedStatement pst=conn.prepareStatement("SELECT * FROM grofers WHERE username=? AND password=?");
                    pst.setString(1, s);
                    pst.setString(2, s1);
                    ResultSet rs=pst.executeQuery();
                    if(rs.next())
                    {
                        new rules();
                       jf.setVisible(false);
                       jf.dispose();
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(jf, "login failed");
                    }
                } 
                catch (SQLException ex)
                {
                    Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        if(obj==jb1)
        {
            jf.setVisible(false);
            jf.dispose();
            String args[]={};
            raek.main(args);
        }
    }
        
    
   
}
