import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
public class rafa 
{
public static void main(String args[])
{
    JFrame f=new JFrame();
    f.setVisible(true);
    f.setSize(800, 800);
//    JPanel jp=new JPanel();
//    jp.setLayout(null);
//    jp.setBounds(0, 0, 600, 600);
//    f.add(jp);
    ImageIcon ii=new ImageIcon("img/Albinder Dhindsa_12-kkb--330x220@LiveMint.jpg");
    JLabel lb=new JLabel(ii);
    lb.setBounds(100, 300, 330, 220);
    f.add(lb);
}
}
