
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class register implements ActionListener {

    JFrame f;
    JLabel lb, lb1, lb2, lb3, lb4, lb5;
    JPanel jp;
    JTextField tf1, tf2, tf3, tf4, tf;
    JPasswordField tp;
    CheckboxGroup cbg;
    Checkbox c1, c2;
    Choice ch, ch1, ch2;
    JButton jb;
    Cursor c;

    public register() {
        f = new JFrame();
        f.setVisible(true);
        f.setSize(1160, 772);
        f.setLocation(100, 0);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(false);
        ImageIcon ii = new ImageIcon("img/vegetable-set-3.jpg");
        lb = new JLabel(ii);
        f.add(lb);
        jp = new JPanel();
        jp.setBounds(0, 0, 1160, 772);
        jp.setOpaque(false);
        jp.setLayout(null);
        lb.add(jp);
        lb1 = new JLabel("FIRST NAME:");
        lb1.setForeground(Color.WHITE);
        lb1.setFont(new Font("comic sans ms", Font.BOLD, 26));
        lb1.setBounds(250, 150, 200, 60);
        jp.add(lb1);
        lb2 = new JLabel("LAST NAME:");
        lb2.setForeground(Color.WHITE);
        lb2.setFont(new Font("comic sans ms", Font.BOLD, 26));
        lb2.setBounds(250, 220, 200, 60);
        jp.add(lb2);
        lb3 = new JLabel("USERNAME:");
        lb3.setForeground(Color.WHITE);
        lb3.setFont(new Font("comic sans ms", Font.BOLD, 26));
        lb3.setBounds(250, 290, 200, 60);
        jp.add(lb3);
        tf = new JTextField();
        tf.setBounds(500, 160, 300, 40);
        jp.add(tf);
        tf1 = new JTextField();
        tf1.setBounds(500, 230, 300, 40);
        jp.add(tf1);
        tf2 = new JTextField();
        tf2.setBounds(500, 300, 300, 40);
        jp.add(tf2);
        lb4 = new JLabel("GENDER:");
        lb4.setFont(new Font("comic sans ms", Font.BOLD, 26));
        lb4.setBounds(250, 360, 200, 60);
        lb4.setForeground(Color.WHITE);
        jp.add(lb4);
        cbg = new CheckboxGroup();
        c1 = new Checkbox("MALE", cbg, true);
        c1.setBounds(500, 370, 100, 40);
        c1.setFont(new Font("comic sans ms", 0, 22));
        jp.add(c1);
        c2 = new Checkbox("FEMALE", cbg, false);
        c2.setFont(new Font("comic sans ms", 0, 22));
        c2.setBounds(650, 370, 150, 40);
        jp.add(c2);
        lb5 = new JLabel("D.O.B");
        lb5.setForeground(Color.WHITE);
        lb5.setFont(new Font("comic sans ms", Font.BOLD, 26));
        lb5.setBounds(250, 430, 200, 60);
        jp.add(lb5);
        ch = new Choice();
        for (int i = 0; i <= 30; i++) {
            ch.add("" + (i + 1));
        }
        ch.setBounds(500, 455, 100, 40);
        jp.add(ch);
        ch1 = new Choice();
        ch1.setBounds(600, 455, 100, 40);
        ch1.add("January");
        ch1.add("February");
        ch1.add("March");
        ch1.add("April");
        ch1.add("May");
        ch1.add("June");
        ch1.add("July");
        ch1.add("August");
        ch1.add("September");
        ch1.add("October");
        ch1.add("November");
        ch1.add("December");
        ch2 = new Choice();
        for (int j = 1930; j <= 2016; j++) {
            ch2.add("" + (j + 1));
        }
        ch2.setBounds(700, 455, 100, 40);
        jp.add(ch1);

        jp.add(ch2);
        jb = new JButton("NEXT");
        jb.setBounds(950, 300, 100, 40);
        jb.setFont(new Font("arial", Font.BOLD, 14));
        jp.add(jb);
        c = new Cursor(Cursor.HAND_CURSOR);
        jb.setCursor(c);
        jb.addActionListener(this);

    }

    public static void main(String args[]) {
        new register();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if (obj == jb) {
            String s = tf.getText().trim();
            String s1 = tf1.getText().trim();
            String s2 = tf2.getText().trim();
            String s3 = cbg.getSelectedCheckbox().getLabel();
            String s4 = ch.getSelectedItem();
            String s5 = ch1.getSelectedItem();
            String s6 = ch2.getSelectedItem();
            if (s.isEmpty() || s1.isEmpty() || s2.isEmpty() || s3.isEmpty() || s4.isEmpty() || s5.isEmpty() || s6.isEmpty()) {
                JOptionPane.showMessageDialog(f, "please fill all the details");
            } else {
                Connection conn = dbconnection.getConnect();
                try {
                    PreparedStatement pst = conn.prepareStatement("INSERT INTO `grofers` (`name`,`username`,`gender`,`dob`) VALUES (?,?,?,?)");
                    pst.setString(1, s + " " + s1);
                    pst.setString(2, s2);

                    if (s3.equals("MALE")) {
                        pst.setString(3, "M");
                    } else if (s3.equals("FEMALE")) {
                        pst.setString(3, "F");
                    }
                    pst.setString(4, s4 + "-" + s5 + "-" + s6);
                    System.out.println("first insert query....." + pst);
                    int check = pst.executeUpdate();
                    if (check == 1) {
                        PreparedStatement select_id = conn.prepareStatement("SELECT id FROM grofers WHERE `username` = ?");
                        select_id.setString(1, s2);
                        ResultSet rs = select_id.executeQuery();
                        if (rs.next()) {
                            int id = rs.getInt("id");
                            f.setVisible(false);
                            f.dispose();
                            new contact(id);
                        } else {
                            System.out.println("data not found............");
                        }
                    } else {
                        System.out.println("data not inserted......");
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(f, ex.getMessage());
                }

            }
        }
    }

}
